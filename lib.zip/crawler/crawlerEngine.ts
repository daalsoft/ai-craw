import { Builder, By, until, WebDriver } from "selenium-webdriver";
import chrome from "selenium-webdriver/chrome";


// 공통 크롤링 함수
export async function crawlSite(driver: WebDriver, config) {
  const jobs = [];

  await driver.get(config.url);

  // 페이지 로딩 대기
  await driver.wait(async () => {
    const items = await driver.findElements(By.css(config.list_item));
    return items.length > 0;
  }, 10000);

  const items = await driver.findElements(By.css(config.list_item));
  console.log(`${config.site_name} 아이템 수:`, items.length);

  for (const item of items) {
    try {
      const titleEl = await item.findElement(By.css(config.title_selector));
      const title = await titleEl.getText();

      let info = "";
      let date = "";
      let link = "";

      if (config.site_name === "naver") {
        // 네이버 전용 처리
        info = await item.findElement(By.css("dl.card_info")).getText();
        const linkEl = await item.findElement(By.css("a.card_link"));
        const onclick = await linkEl.getAttribute("onclick");

        if (onclick) {
          const match = onclick.match(/'(\d+)'/);
          if (match) {
            const annoId = match[1];
            link = `https://recruit.navercorp.com/rcrt/view.do?annoId=${annoId}`;
          }
        }

        const infoParts = info.split("\n");
        date = infoParts[infoParts.length - 1] || "";
      } else {
        // 일반 사이트 처리
        if (!config.is_modal && config.detail_selector) {
          const linkEl = await item.findElement(By.css(config.detail_selector));
          link = await linkEl.getAttribute("href");
        }
      }

      jobs.push({
        site: config.site_name,
        title,
        info,
        date,
        link
      });
    } catch (err) {
      console.log("개별 아이템 실패:", err.message);
    }
  }

  return jobs;
}
