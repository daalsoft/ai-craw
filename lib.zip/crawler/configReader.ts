import path from "path";
import fs from "fs";
import * as XLSX from "xlsx";
import { SiteConfig } from "@/lib/config/siteConfig"; // 타입 임포트

export function readSiteConfig(relativePath: string): SiteConfig[] {
  const absPath = path.join(process.cwd(), relativePath);
  
  try {
    // 1. 파일 존재 여부 먼저 체크 (디버깅용)
    if (!fs.existsSync(absPath)) {
      throw new Error(`파일이 존재하지 않습니다: ${absPath}`);
    }

    // 2. 버퍼로 읽기 (Next.js 권장 방식)
    const fileBuffer = fs.readFileSync(absPath);
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });

    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    
    // 3. 데이터를 SiteConfig 타입의 배열로 변환
    const data = XLSX.utils.sheet_to_json<SiteConfig>(sheet, {
      defval: "",      // 빈 셀도 유지
      blankrows: false // 빈 행 제거
    });

    
    return data;
  } catch (err) {
    console.error("Excel 읽기 실패:", err);
    throw err;
  }
}