import { Builder } from "selenium-webdriver";
import chrome from "selenium-webdriver/chrome";

export async function createDriver() {
  const service = new chrome.ServiceBuilder(
    "C:/drivers/chromedriver.exe"
  );

  const options = new chrome.Options();
  options.addArguments("--headless=new");
  options.addArguments("--no-sandbox");
  //options.addArguments("--disable-gpu");
  options.addArguments("--disable-dev-shm-usage")

  return await new Builder()
    .forBrowser("chrome")
    .setChromeService(service)
    .setChromeOptions(options)
    .build();
}

